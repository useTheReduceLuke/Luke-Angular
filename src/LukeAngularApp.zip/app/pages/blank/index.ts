export * from './blank.component';
