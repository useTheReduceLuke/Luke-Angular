export * from './resume.component';
